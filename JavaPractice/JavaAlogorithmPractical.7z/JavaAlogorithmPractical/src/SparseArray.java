import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class SparseArray {

	public static void main(String[] args) {
		
		
		String[] arr1= {"abc" , "ab" ,"ex","abc" , "ab","zero","hello"};
		String[] arr2 = {"abc" , "ab" ,"exm","hello"};
		
		List<String> l1 = Arrays.asList(arr1);
		List<String> l2 = Arrays.asList(arr2);
		for(String st : l2){
			System.out.println(Collections.frequency(l1,st));
		}
		
	}
}
