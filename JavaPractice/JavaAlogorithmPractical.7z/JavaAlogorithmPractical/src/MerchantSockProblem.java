import java.util.Arrays;
import java.util.Scanner;


public class MerchantSockProblem {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numberOfSocks = in.nextInt();
		int totalPairs=0;
		
		int[] ar = new int[numberOfSocks];
		
		for(int i=0; i<numberOfSocks ; i++){
			ar[i] = in.nextInt();
		}
		
		System.out.println(Arrays.toString(ar));
		Arrays.sort(ar);
		System.out.println(Arrays.toString(ar));
		
		
		for(int i=0 ; i<numberOfSocks-1 ; i++){
			System.out.println("array value is "+ar[i]);
			if( ar[i] == ar[i+1]){
				totalPairs++;
				System.out.println("before i value is " + i);
				i = i+1;
				System.out.println("i value is "+i);
			}
			
		}
		System.out.println("total pairs are " + totalPairs);
		
		
		
	}

}
