import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class TestHashMapLoopingLambda {
	public static void main(String[] args) {
		// Setting up a HashMap
		  Map<String, String> cityMap = new HashMap<String, String>();
		  cityMap.put("1","New York City" );
		  cityMap.put("2", "New Delhi");
		  cityMap.put("3", "Newark");
		  cityMap.put("4", "Newport");
		  
		  System.out.println("Looping with Lambda expression forEach stmt"); 
		  Set<Map.Entry<String, String>> valueSet = cityMap.entrySet();
		  valueSet.forEach((a)->System.out.println("Key is " + a.getKey() + 
		           " Value is " + a.getValue()));
		  
		  System.out.println("Looping with method reference forEach");
		  cityMap.entrySet().forEach(System.out::println);
		  // Looping HashMap directly with forEach
		  System.out.println("Looping HashMap with forEach statement");
		  cityMap.forEach((K,V)->System.out.println("Key is " + K + " Value is " + V));
		 }
	

}
