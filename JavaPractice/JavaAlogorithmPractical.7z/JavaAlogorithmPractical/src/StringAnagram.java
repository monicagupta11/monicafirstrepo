import java.util.Arrays;

/**
Two strings are considered anagram when each character of one string is same as in another string but order could of char could be different
logic
take each string , convert to char array , sort it and then compare it
 * @author monicag
 *
 */
public class StringAnagram {
	
	public static void main(String[] args) {
		
		String s1= "monica";
		String s2= "ancimo";
		
		if(s1.length() == s2.length()){
			char[] ar1 = s1.toCharArray();
			char[] ar2 = s2.toCharArray();
			
			Arrays.sort(ar1);
			Arrays.sort(ar2);
			System.out.println(ar1);
			System.out.println(ar1);
			
			boolean isAnagram = Arrays.equals(ar1, ar2);
			if(isAnagram){
				System.out.println("Both strings are anagram");
			}
		}
	}

}
