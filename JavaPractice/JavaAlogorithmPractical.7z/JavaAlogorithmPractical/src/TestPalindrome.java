import java.util.Scanner;


public class TestPalindrome {
	
	public static void main(String[] args) {
		
		int inputnumber=12321;
		int temp;
		int sum=0;
		int lastdigit;
		
		// copy to temp varibale
		temp= inputnumber;
		
		// logic to reverse number
		while(temp>0){
			
			lastdigit = temp %10;
			sum = sum * 10 + lastdigit;
			temp = temp/10;
			
		}
		
		
		
		
		System.out.println("reverse number is " + sum);
		
		if(sum == inputnumber){
			System.out.println("Its palindrome");
		}else
		{
			System.out.println("not palindrome");
		}
			
		
		
	// String palindrome
			String original = "madamss";
			
			String reverse="";
			
			int len = original.length();
			
			for(int i= len-1; i>=0 ;i--){
				reverse = reverse + original.charAt(i);
			}
			
			System.out.println("reverse of string is " + reverse);
			
			if(original.equals(reverse)){
				System.out.println("String is palindrome");
			}else
			{
				System.out.println("not palindrome");
			}
	}
	
}

