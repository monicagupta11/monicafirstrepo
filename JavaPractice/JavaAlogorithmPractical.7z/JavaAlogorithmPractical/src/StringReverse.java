
public class StringReverse {
	
	public static void main(String[] args) {
		
		String s="monica";
		String rev="";
		
		for(int i=s.length()-1;i>=0 ;i--){
			rev = rev + s.charAt(i);
		}
		
		System.out.println("reverse is " + rev);
		
		StringBuffer bufer = new StringBuffer(s);
		bufer.reverse();
		
		System.out.println(bufer);
	}

}
